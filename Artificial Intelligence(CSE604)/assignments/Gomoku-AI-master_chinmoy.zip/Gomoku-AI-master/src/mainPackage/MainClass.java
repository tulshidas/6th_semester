package mainPackage;

import gameStatePacakge.GameGraphicsManagement;

public class MainClass {
	public static void main(String[] args) {
		new GameGraphicsManagement().start();
	}
}
