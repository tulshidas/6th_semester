package temporary;

public class Main {

	public static void main(String[] args) {
//		int w = new Minimax().play();
//		int w = new GameManipulation().play();
//		if (w == 10)
//			System.out.println("CpU won");
//		else if (w == -10)
//			System.out.println("You won");
//		else
//			System.out.println("Its tie");
	}

}

/*
 0, 0, -8
0, 1, -9
0, 2, -8
1, 0, -8
1, 2, -8
2, 1, -10
2, 2, -8
*/
