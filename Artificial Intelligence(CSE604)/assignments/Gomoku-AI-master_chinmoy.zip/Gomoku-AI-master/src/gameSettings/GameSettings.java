package gameSettings;

public class GameSettings {
	// game properties
	public static String title = "Gomoku-AI";
	public static int height = 600;
	public static int width = 900;

	// location on monitor
	public static int loacationX = 500;
	public static int locationY = 200;

	// board size
	public static int rowColom = 10;

}
