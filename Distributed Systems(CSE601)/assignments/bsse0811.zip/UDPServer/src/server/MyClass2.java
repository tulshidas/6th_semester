package server;

public class MyClass2 {

	public String remoteMethod(){
		return "Returned from ServerMethod remote method";
	}
	
	public String remoteMethod1(){
		return "Returned from MyClass2 ServerMethod remoteMethod1";
	}
	
	public String remoteMethod2(){
		return "Returned from MyClass2 ServerMethod remoteMethod2";
	}
}
