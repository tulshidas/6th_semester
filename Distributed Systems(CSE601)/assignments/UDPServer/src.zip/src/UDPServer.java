import java.net.*;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
public class UDPServer{
	public static void main(String args[]) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		DatagramSocket aSocket = null;
		try{
			aSocket = new DatagramSocket(6789);
			byte[] buffer = new byte[1000];
			while(true){
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
				aSocket.receive(request);
				MyClass cClass = new MyClass();
				String methodName = new String(request.getData(),"UTF-8");
				String realMethodName = methodName.substring(0, 12);
				System.out.println("method:"+realMethodName+realMethodName.length());
				Method method = MyClass.class.getDeclaredMethod(realMethodName);
				String retValue = (String) method.invoke(cClass);
				/*DatagramPacket reply = new DatagramPacket(request.getData(),
						request.getLength(), request.getAddress(), request.getPort());*/
				DatagramPacket reply = new DatagramPacket(retValue.getBytes(),
						retValue.length(), request.getAddress(), request.getPort());
				
				aSocket.send(reply);
			}
		} catch (SocketException e){System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {System.out.println("IO: " + e.getMessage());
		} finally {if (aSocket != null) aSocket.close();}
	}
	
	
	
}