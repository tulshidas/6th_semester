
public class MyClass {

	public String remoteMethod(){
		return "Returned from ServerMethod";
	}
	
}
